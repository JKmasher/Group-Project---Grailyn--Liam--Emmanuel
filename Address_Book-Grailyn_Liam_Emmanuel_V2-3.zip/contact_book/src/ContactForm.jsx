import React, { useState } from 'react'

const ContactForm = () => {
    const [firstName, setFirstName] = useState("")
    const [lastName, setLastName] = useState("")
    const [email, setEmail] = useState("")
    const [phone, setPhone] = useState("")
    const [streetNumber, setStreetNumber ] = useState("")
    const [streetName, setStreetName] = useState("")
    const [streetType, setStreetType] = useState("")
    const [cityName, setCityName] = useState("")
    const [state, setState] = useState("")

    const saveContact = async (e) => {
        e.preventDefault();
        const formData = {
            first_name: firstName,
            last_name: lastName,
            email: email,
            phone: phone,
            const_number: streetNumber,
            const_street_name: streetName,
            const_street_type: streetType,
            const_city_name: cityName,
            const_state: state
        }
        console.log(formData)

        try {
            const response = await fetch('http://127.0.0.1:5000/contacts/new', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData),
            });

            if (response.ok) {
                const responseData = await response.json();
                console.log(responseData.body)

            }
        } catch (error) {
            console.error('Error during Creation:', error);
        }

    };

    return (
        <div>
            <h2>Create a <p className='text-primary'>Contact</p></h2>
            <div className="" style={{ display: "flex", justifyContent: "space-evenly" }}>
                <div>
                    <div className="">
                        <label htmlFor="">First Name:<input type="text" name="first_name" placeholder="First Name" className="form-control" value={firstName} onChange={(e) => setFirstName(e.target.value)} /></label>
                    </div>
                    <div className="">
                        <label htmlFor="">Last Name:<input type="text" name="last_+name" placeholder="Last Name" className="form-control" value={lastName} onChange={(e) => setLastName(e.target.value)} /></label>            </div>
                    <div className="">
                        <label htmlFor="">Phone:
                            <input type="text" name="phone" placeholder="Phone Number" className="form-control"
                                pattern="[0-9]{5}[-][0-9]{7}[-][0-9]{1}" value={phone} onChange={(e) => setPhone(e.target.value)} />
                        </label>
                    </div>
                    <div className="">
                        <label htmlFor="">Email:<input type="text" name="email" placeholder="Email Id" className="form-control" value={email} onChange={(e) => setEmail(e.target.value)} /></label>
                    </div>
                </div>
                <div>
                    <div className="">
                        <label htmlFor="|">Street Number<input type="text" name="const_number" placeholder="Address" className="form-control" value={streetNumber} onChange={(e) => setStreetNumber(e.target.value)} /></label>
                    </div>
                    <div className="">
                        <label htmlFor="|">Street Name<input type="text" name="const_street_name" placeholder="Address" className="form-control" value={streetName} onChange={(e) => setStreetName(e.target.value)} /></label>
                    </div>
                    <div className="">
                        <label htmlFor="|">Street Type<input type="text" name="const_street_type" placeholder="Address" className="form-control" value={streetType} onChange={(e) => setStreetType(e.target.value)} /></label>
                    </div>

                    <div className="">
                        <label htmlFor="">City:<input type="text" name="const_city_name" placeholder="City" className="form-control" value={cityName} onChange={(e) => setCityName(e.target.value)} /></label>
                    </div>
                    <div className=" " name="const_state" >
                        <label htmlFor="">
                            State:
                            <select value={state} onChange={(e) => setState(e.target.value)}>
                                <option value="AL">AL</option>
                                <option value="AK">AK</option>
                                <option value="AR">AR</option>
                                <option value="AZ">AZ</option>
                                <option value="CA">CA</option>
                                <option value="CO">CO</option>
                                <option value="CT">CT</option>
                                <option value="DC">DC</option>
                                <option value="DE">DE</option>
                                <option value="FL">FL</option>
                                <option value="GA">GA</option>
                                <option value="HI">HI</option>
                                <option value="IA">IA</option>
                                <option value="ID">ID</option>
                                <option value="IL">IL</option>
                                <option value="IN">IN</option>
                                <option value="KS">KS</option>
                                <option value="KY">KY</option>
                                <option value="LA">LA</option>
                                <option value="MA">MA</option>
                                <option value="MD">MD</option>
                                <option value="ME">ME</option>
                                <option value="MI">MI</option>
                                <option value="MN">MN</option>
                                <option value="MO">MO</option>
                                <option value="MS">MS</option>
                                <option value="MT">MT</option>
                                <option value="NC">NC</option>
                                <option value="NE">NE</option>
                                <option value="NH">NH</option>
                                <option value="NJ">NJ</option>
                                <option value="NM">NM</option>
                                <option value="NV">NV</option>
                                <option value="NY">NY</option>
                                <option value="ND">ND</option>
                                <option value="OH">OH</option>
                                <option value="OK">OK</option>
                                <option value="OR">OR</option>
                                <option value="PA">PA</option>
                                <option value="RI">RI</option>
                                <option value="SC">SC</option>
                                <option value="SD">SD</option>
                                <option value="TN">TN</option>
                                <option value="TX">TX</option>
                                <option value="UT">UT</option>
                                <option value="VT">VT</option>
                                <option value="VA">VA</option>
                                <option value="WA">WA</option>
                                <option value="WI">WI</option>
                                <option value="WV">WV</option>
                                <option value="WY">WY</option>
                            </select>
                        </label>
                    </div>
                    <div className="col-md-12 sub-but" ><button onClick={saveContact} className="btn btn-general btn-white" role="button">Save</button></div>
                </div>
            </div>
        </div>
    )
}
export default ContactForm
