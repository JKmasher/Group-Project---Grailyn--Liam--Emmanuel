import React, { useContext, useEffect } from 'react';
import { CoordinateContext } from './CoordinateProvider';
const GeoCoding = () => {
  const {setCoords, location} = useContext(CoordinateContext)
  const {number, street_name, street_type, city, state} = location[0];
  console.log(number)
  useEffect(()=>{
    getGeoCoding();
  })

    const api_key = "AIzaSyAxX0hzA2Gt3w73ciJcSMEdErLIZ5Mo-HY";
    const getGeoCoding = async() => {
      try {
        const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?address=${number}+${street_name}+${street_type},+${city},+${state}&key=${api_key}`, {
          method: 'GET',
        });
        if (response.ok) {
          const responseData = await response.json();
          const coords = {
            zoom: "603",
            latitude: responseData.results[0].geometry.location.lat,
            longitude: responseData.results[0].geometry.location.lng
          }
          setCoords(coords);
        }
      }
      catch (error) {
        console.error('Error during fetch:', error);
      }
    }
    
    return (
      <>
      </>
    )    
}

export default GeoCoding
