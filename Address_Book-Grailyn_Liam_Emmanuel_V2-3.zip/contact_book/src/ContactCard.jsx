import React, { useContext, useEffect, useState } from 'react';
import { CoordinateContext } from './CoordinateProvider';
import ContactUpdateForm from './ContactUpdateForm'

const ContactCard = (props) => {
    const { setLocation, location, setContacts, setCoords, setUpdateForm, setComponents } = useContext(CoordinateContext);
    const { contact } = props;
    const [display, setDisplay] = useState(false);
    const style = {
        color: '#4267b2',
        borderColor: '#4267b2'
    }
    const api_key = "AIzaSyAxX0hzA2Gt3w73ciJcSMEdErLIZ5Mo-HY";

    const getGeoCoding = async () => {
        if (!location || location.length === 0) return; 

        const { number='', street_name='', street_type='', city='', state='' } = location[0];

        if (number.length > 0) {
            try {
                const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?address=${number}+${street_name}+${street_type},+${city},+${state}&key=${api_key}`, {
                    method: 'GET',
                });
                if (response.ok) {
                    const responseData = await response.json();
                    const coords = {
                        zoom: "603",
                        latitude: responseData.results[0]?.geometry.location.lat,
                        longitude: responseData.results[0]?.geometry.location.lng
                    };
                    setCoords(coords);
                }
            } catch (error) {
                console.error('Error during fetch:', error);
            }
        }
    }

    const toggleDisplay = () => {
        setDisplay(!display);
        setComponents([])
        setLocation([{
            number: contact.const_number,
            street_name: contact.const_street_name,
            street_type: contact.const_street_type,
            city: contact.const_city_name,
            state: contact.const_state
        }]);
    }

    useEffect(() => {
        if (display) {
            getGeoCoding(); 
        } 
    }, [location, display]);
    const updateContact = async () => {
        // setUpdateForm(contact)
        console.log("From card update: ",contact)
        setComponents(<ContactUpdateForm contact={contact} />)

    }
    const deleteContact = async () => {
        try {
            const response = await fetch(`http://127.0.0.1:5000/contacts/delete/${contact.id}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
            });
    
            if (!response.ok) {
                throw new Error(`Error: ${response.statusText}`);
            }
    
            console.log("Successfully deleted contact:", contact.id);
            setContacts((prevContacts) => {
                const updatedContacts =  prevContacts.filter((one) => one.id !== contact.id);
                return updatedContacts; 
            });
    
            const data = await response.json();
            console.log("Contact deleted successfully:", data);
        } catch (error) {
            console.error("Error deleting contact:", error);
        }
    };
    

    return (
        <div className=''>
            <section className=" " >
                <div className="" id="contact" >
                    <div className="">
                        <div className="" style={{ display: 'flex' }}>
                            <h3>
                                <span className="text-primary" onClick={toggleDisplay}>{contact.first_name} {contact.last_name}</span>
                            </h3>

                            {/* onClick to delete */}
                            <div style={{ display: 'flex', margin: '0', alignSelf: 'flex-end' }}>
                                {display &&
                                    <div style={{ display: 'flex', color: "black" }}>
                                        <>
                                            <button onClick={updateContact} style={{ height: "50px", color: "black", backgroundColor: "yellow", border: "5px solid black" }}>
                                                !
                                            </button>
                                            <p style={{ fontWeight: "900" }}>Update</p>
                                        </>
                                        <>
                                            <button onClick={deleteContact} style={{ height: "50px", alignContent: 'center', textAlign: "center", color: "black", backgroundColor: "red", border: "5px solid black" }}>
                                                X
                                            </button>
                                            <p style={{ fontWeight: "900" }}>Delete</p>
                                        </>
                                    </div>
                                }
                            </div>

                            <div className=""></div>
                        </div>
                        {display &&
                            <div className="col-md-4 col-sm-12 " >
                                <div className="" style={{ display: 'flex', flexDirection: "row", justifyContent: "space-between", gap: "5rem" }}>
                                    <div className="contact-mail contact-side-desc contact-box-desc">
                                        <h3><i className="fa fa-map-marker cl-atlantis fa-2x"></i> Address</h3>
                                        <p>{contact.const_number} {contact.const_street_name} {contact.const_street_type}</p>
                                        <p>{contact.const_city_name} {contact.const_state}</p>
                                    </div>
                                    <div className="contact-mail contact-side-desc contact-box-desc">
                                        <h3><i className="fa fa-phone cl-atlantis fa-2x" style={{ width: "150px" }}></i> Phone</h3>
                                        <p>{contact.phone}</p>
                                    </div>
                                    <div className="contact-mail contact-side-desc contact-box-desc" style={{ width: "150px" }}>
                                        <h3><i className="fa fa-envelope-o cl-atlantis fa-2x"></i> Email</h3>
                                        <address className="address-details-f">
                                            Email: <a href={`mailto:${contact.email}`}>{contact.email}</a>
                                        </address>
                                        <ul className="list-inline social-icon-f top-data">
                                            <li><a href="#" target="_empty"><i className="fa top-social fa-facebook" style={style}></i></a></li>
                                            <li><a href="#" target="_empty"><i className="fa top-social fa-twitter" style={style}></i></a></li>
                                            <li><a href="#" target="_empty"><i className="fa top-social fa-google-plus" style={style}></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>}
                    </div>
                </div>
            </section>
        </div>
    );
}

export default ContactCard;
