import React, { useEffect, useState, useContext } from 'react';
import GeoCoding from './GeoCoding';
import ContactForm from './ContactForm';
import Navigation from './Navigation';
import ContactUpdateForm from './ContactUpdateForm';
import ContactDirectory from './ContactDirectory';
import GeoMap from './GeoMap';

// Adjust the import according to how you exported the context and provider
import { CoordinateContext } from './CoordinateProvider'; // Importing only the context

const App = () => {
    const { coords, contacts, setContacts, components } = useContext(CoordinateContext); // Destructure the context directly
    

    useEffect(() => {
        const fetchContacts = async () => {
            try {
                const response = await fetch('http://127.0.0.1:5000/contacts', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                });

                if (!response.ok) {
                    throw new Error("Network response was not ok");
                }
                const responseData = await response.json();
                setContacts(responseData)
            } catch (error) {
                console.error('Error fetching contacts:', error);
            }
        };

        fetchContacts();
    }, []);
    
    return (
        <div style={{width: "650px"}}>
            <Navigation />
            {components}
            {/* <ContactForm />
            <ContactUpdateForm /> */}
            <ContactDirectory  />
            <GeoMap coords={coords} />
        </div>
    );
}

export default App;
