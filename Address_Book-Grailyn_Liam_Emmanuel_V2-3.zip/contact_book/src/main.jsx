import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import {CoordinateProvider} from './CoordinateProvider.jsx'
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CoordinateProvider>
      <App />
    </CoordinateProvider>
  </React.StrictMode>,
)
