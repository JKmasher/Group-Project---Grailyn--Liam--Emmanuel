import React, { createContext, useState } from 'react';

const CoordinateContext = createContext();

const CoordinateProvider = ({ children }) => {
    const [coords, setCoords] = useState([]);
    const [contacts, setContacts] = useState([]);
    const [location, setLocation] = useState([]);
    const [contact, setUpdateForm] = useState([]);
    const [components, setComponents] = useState([]);
    const [filter, setFilter] = useState([]);

    return (
        <CoordinateContext.Provider value={{ 
            coords, setCoords, 
            location, setLocation, 
            contacts, setContacts, 
            contact, setUpdateForm,
            components, setComponents,
            filter, setFilter
             }}>
            {children} 
        </CoordinateContext.Provider>
    );
}

export  {CoordinateContext, CoordinateProvider}
