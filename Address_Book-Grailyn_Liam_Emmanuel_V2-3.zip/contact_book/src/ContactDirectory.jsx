import React, { useContext, useEffect, useState } from 'react';
import ContactCard from './ContactCard';
import ContactByAlpha from './ContactByAlpha';
import { CoordinateContext } from './CoordinateProvider';
const ContactDirectory = () => {
    const {contacts, setContacts, filter} = useContext(CoordinateContext)
    // const [filter, setFilter] = useState('');

    useEffect(() => {
        const filteredResult = contacts.filter((contact) => {

            contact && (filter === '' ||contact.first_name[0].toLowerCase() === filter)
        });
        
        if (filter === "") {
            setContacts(contacts);
        } else {
            setContacts(filteredResult);
        }
    }, [filter]);

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '.25rem', margin: '0', padding: '0' }}>
            {/* <ContactByAlpha  /> */}
            {contacts.map((contact, index) => (
                contact === undefined ? null : <ContactCard key={index} contact={contact} />
            ))}
        </div>
    );
};

export default ContactDirectory;
