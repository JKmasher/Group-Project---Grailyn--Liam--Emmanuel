import React, {useContext} from 'react'
import { CoordinateContext } from './CoordinateProvider';

const ContactByAlpha = (props) => {
    const {filter, setFilter} = useContext(CoordinateContext)
    // const {filter} = props;
    const alpha = Array.from({ length: 26 }, (_, i) => String.fromCharCode(97 + i));
    const handleClick = (letter) => {
        setFilter(letter)
        // setFilter(letter);
    }

    return (

        <div style={{display:'flex', flexDirection:'column'}}>
            <h4>Contact List</h4>
            <ul style={{display:'flex', listStyle: 'none', gap:'.5rem', justifyContent:'space-between', flexWrap:'wrap'}}>
                <li>
                <button style={{ display: 'flex', justifyContent: 'center', fontSize: '.5rem',alignItems: 'center', height:'15px', width:' 15px'}} onClick={(e) => { handleClick("") }} >All</button>
                </li>
                {alpha.map((letter, index) => {
                    return (
                        <li key={index}>
                            <button style={{ display: 'flex', justifyContent: 'center', fontSize: '.5rem',alignItems: 'center', height:'15px', width:' 15px'}} onClick={(e) => { handleClick(letter) }} >{letter}</button>
                        </li>)
                })}

            </ul>

        </div>
    )
}

export default ContactByAlpha
