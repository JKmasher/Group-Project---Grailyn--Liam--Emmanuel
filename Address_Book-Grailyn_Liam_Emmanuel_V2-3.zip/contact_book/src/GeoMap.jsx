import React from 'react'

const GeoMap = (props) => {
    const {coords} = props;
    const {zoom, longitude, latitude} = coords
    return (
        <>
            <section className=" d-flex flex-column" id="maps">
                <div id="map">
                    <div className="map-responsive">
                        <iframe src={`https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d${zoom}!2d${longitude}!3d${latitude}!3m2!1i1024!2i768!4f13.1!5e0!3m2!1ses-419!2smx!4v1471908546569`} width="600" height="450" frameBorder="0" style={{border:"0"}} allowFullScreen></iframe>
                    </div>
                </div>
            </section>
        </>
    )
}

export default GeoMap