from flask_app import app
from flask_app.controllers import users, contacts
from flask_cors import CORS
CORS(app)

#Run the application
if __name__ == '__main__':
    app.run(debug=True)