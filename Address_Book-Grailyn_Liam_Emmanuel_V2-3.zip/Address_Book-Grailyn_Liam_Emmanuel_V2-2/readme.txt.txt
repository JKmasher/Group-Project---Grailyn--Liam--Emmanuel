A description of the project, its stack, a feature list, and GitHub repo link (can be empty at this point). You can include a product backlog that you plan to work on once your MVP is done

This is an Address Book to save and track contacts for various purposes.
The Stack will be HTML, Python, Flask, Bootstrap or CSS, and MySQL, REACT, Google API, Javascript

GitHub Repository link:
in progress*******************************

Wireframe shell is compelted
ERD SQL Database is progress*********************

Features are:
Contacts main profile page
About
Experience
Portfolio link

Contacts
Full Name
Email
Address
Phone
Email
Google API of Map location

