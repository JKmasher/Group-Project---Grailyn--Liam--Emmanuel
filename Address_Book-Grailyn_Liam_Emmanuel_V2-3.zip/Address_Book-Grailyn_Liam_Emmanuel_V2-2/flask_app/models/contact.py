from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app.models.basemodel import BaseModel
from flask_app.models.user import User
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
# from wtforms.validators import NumberRange                              # trying to get "MVP requirement done, Duration must be a positive number with range of 1 hour min - 8 hours max"

class Contact(BaseModel):
    db = "address_book_schema"
    json_fields = ['id', 'first_name', 'last_name', 'email', 'phone', 'const_number', 'const_street_name', 'const_street_type', 'const_city_name', 'const_state']

    def __init__(self, contact):
        print(f"From constructor: {contact}")
        self.id = contact["id"]
        self.first_name = contact['first_name']
        self.last_name = contact['last_name']
        self.email = contact['email']
        self.phone = contact['phone']
        self.const_number = contact['const_number']
        self.const_street_name = contact['const_street_name']
        self.const_street_type = contact['const_street_type']
        self.const_city_name = contact['const_city_name']
        self.const_state = contact['const_state']
        # self.user_id = contact['user_id']                         # commented out, avoiding user auth for now
        self.created_at = contact['created_at'] if 'created_at' in contact else None
        self.updated_at = contact['updated_at'] if 'updated_at' in contact else None
        # self.user = None                                                # leave it as None.

    @classmethod
    def get_one_by_id(cls, contact_id):
        query = "SELECT * FROM contacts WHERE contacts.id = %(id)s"
        contact_dict = connectToMySQL(cls.db).query_db(query, {'id':int(contact_id)})
        contact_obj = cls(contact_dict[0])
        return contact_obj.to_json()

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM contacts;"                                     # Get all contacts
        results = connectToMySQL(cls.db).query_db(query)
        contacts = []                                                         # Create an empty list to hold all the contacts
        for contact_dict in results:                                          # Make a forLoop to Iterate through the list of tree dictionaries
            contact_obj = Contact(contact_dict)                               # convert data into a tree object
            contacts.append(contact_obj)                                      # Add/Append new tree to the list
        return contacts                                                       # Send the list of trees back to the Controller... aka Return the list of trees

# **CREATE VALID Contact**
    @classmethod
    def save(cls, contact_data):
        if cls.is_valid(contact_data) == False:
            return False
        else:
            query = """
            INSERT INTO contacts (first_name, last_name, email, phone, const_number, const_street_name, const_street_type, const_city_name, const_state) 
            VALUES (%(first_name)s, %(last_name)s, %(email)s, %(phone)s, %(const_number)s, %(const_street_name)s, %(const_street_type)s, %(const_city_name)s, %(const_state)s);
            """
        connectToMySQL(cls.db).query_db(query, contact_data)
        return True

    @classmethod                                                        # Delete contact by id
    def delete_by_id(cls, contact_id):
        query = "DELETE FROM contacts WHERE id = %(id)s"
        data = {
            "id": contact_id
        }
        connectToMySQL(cls.db).query_db(query, data)

    @classmethod
    def update(cls, contact_data):
        print(f"From model at update: {contact_data}")
        if cls.is_valid(contact_data) == False:
            return False
        else:
            query = """
            UPDATE contacts 
            SET first_name = %(first_name)s, 
            last_name = %(last_name)s, 
            email = %(email)s, phone = %(phone)s, 
            const_number = %(const_number)s, 
            const_street_name = %(const_street_name)s, 
            const_street_type = %(const_street_type)s, 
            const_city_name = %(const_city_name)s, 
            const_state = %(const_state)s 
            WHERE id = %(id)s;
            """
            connectToMySQL(cls.db).query_db(query, contact_data)             # This last parameter has to match the same name in line 102
            return cls(contact_data)

    @staticmethod
    def is_valid(contact_dict):      
        print(f"Validation Error: {contact_dict}")
        # **VALIDATE Contact**
        valid = True                                                # Set valid variable to True
        if type(contact_dict) != dict:                              # Check if the contact_dict is a dictionary
            contact_dict = contact_dict.to_dict()                   # Convert the ImmutableMultiDict to a dictionary
        if len(contact_dict["first_name"]) == 0:                    # Prescence Validation
            valid = False
            flash("First Name is required.")
        elif len(contact_dict["first_name"]) < 2:                   # Require At least 2 characters for 'First Name'.
            valid = False
            flash("First Name must be at least 2 characters.")

        if len(contact_dict["last_name"]) == 0:                     # Prescence Validation
            valid = False
            flash("Last Name is required.")
        elif len(contact_dict["last_name"]) < 3:                    # Require At least 3 characters for Description.
            valid = False
            flash("Last Name must be at least 3 characters.")

        if len(contact_dict["email"]) == 0:                         # Prescence Validation
            valid = False
            flash("Email is required.")

        if len(contact_dict["phone"]) == 0:                         # Prescence Validation
            valid = False
            flash("Phone is required.")
        else:
            contact_dict["phone"]                              # using len() to check the length of the phone number, and typecasting it to an intege
            if len(contact_dict["phone"]) < 1 or len(contact_dict["phone"]) > 15:
                valid = False
                flash("Please enter a valid phone number")

        if len(contact_dict["const_number"]) == 0:                  # Prescence Validation
            valid = False
            flash("Street Number is required.")

        if len(contact_dict["const_street_name"]) == 0:             # Prescence Validation
            valid = False
            flash("Street Name is required.")

        if len(contact_dict["const_street_type"]) == 0:             # Prescence Validation
            valid = False
            flash("Street Type is required, such as blvd, ave, or st.")

        if len(contact_dict["const_city_name"]) == 0:               # Prescence Validation
            valid = False
            flash("City Name is required.")

        if len(contact_dict["const_state"]) == 0:                   # Prescence Validation
            valid = False
            flash("State is required.")

        print(f"Is valid: {valid}")
        return valid