from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app.models.basemodel import BaseModel                    # -->  Liam added the link to the BaseModel
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
PASSWORD_REGEX = re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$')

class User(BaseModel):

    users = []                                                                                          # -->  Liam added this line to the User class
    json_fields = ['id', 'first_name', 'last_name', 'email', 'password', 'created_at', 'updated_at']    # -->  Liam added this line to the User class

    db = "address_book_schema"
    def __init__(self,data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.users.append(self)                                                                         # -->  Liam added this line to the User class based on instructer model

    @classmethod
    def save(cls,data):
            query = "INSERT INTO users (first_name, last_name, email, password) VALUES(%(first_name)s,%(last_name)s,%(email)s,%(password)s)"
            return connectToMySQL(cls.db).query_db(query,data)

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM users;"
        results = connectToMySQL(cls.db).query_db(query)
        users = []
        for row in results:
            users.append( cls(row))
        return users

    @classmethod
    def get_by_email(cls,data):
        print(data)
        query = "SELECT * FROM users WHERE email = %(email)s;"
        results = connectToMySQL(cls.db).query_db(query,data)
        if len(results) < 1:
            return False
        return cls(results[0])

    @classmethod
    def get_by_id(cls,data):
        query = "SELECT * FROM users WHERE id = %(id)s;"
        results = connectToMySQL(cls.db).query_db(query,data)
        return cls(results[0])

    @staticmethod
    def validate_register(user):
        is_valid = True

        if not user['first_name'].strip():                                  # Prescence Validation
            flash("First name required","register")
            is_valid=False
        elif len(user['first_name']) < 2:
            flash("First name must be at least 2 characters","register")
            is_valid=False

        if not user['last_name'].strip():                                   # Prescence Validation
            flash("last name required","register")
            is_valid=False
        elif len(user['last_name']) < 2:
            flash("Last name must be at least 2 characters","register")
            is_valid=False

        if not user['email'].strip():                                       # Prescence Validation
            flash("email required","register")
            is_valid=False

        elif User.get_by_email(user) == user['email']:                      #  Validation to make sure Email does not already exist, must be unique
            flash("Email already taken.","register")
            is_valid=False
        elif not EMAIL_REGEX.match(user['email']):
            flash("Invalid Email.","register")
            is_valid=False

        if not user['password'].strip():                                    # Prescence Validation
            flash("password required","register")
            is_valid=False
        elif not PASSWORD_REGEX.match(user['password']):                    #  Validation to make sure Password meets requirements
            flash("Password must contain at least 1 uppercase letter, 1 lowercase letter, and 1 number.","register")
            is_valid = False
        elif user['password'] != user['confirm']:                           #  "confirm" must be same name in the 'login_reg.html' on the line.....<label for="confirm">Confirm Password:</label>
            flash("Please ensure you enter matching passwords","register")
            is_valid = False
        return is_valid