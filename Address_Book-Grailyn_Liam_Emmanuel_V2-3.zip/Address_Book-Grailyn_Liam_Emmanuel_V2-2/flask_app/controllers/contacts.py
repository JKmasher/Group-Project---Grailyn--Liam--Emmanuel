from flask import render_template, session, redirect, request, flash, jsonify            # do not import Flask here, only the __init__.py file
from flask_app import app
from flask_app.models.user import User
from flask_app.models.contact import Contact
from flask_app.config.mysqlconnection import connectToMySQL
import json

@app.route("/contacts")
def contact_home():
    contacts = Contact.get_all()
    results = [contact.to_json() for contact in contacts]
    print(f"From controller: {results}")
    return jsonify(results), 200

@app.route('/contacts/details/<int:contact_id>')
def contact_details(contact_id):
    contact = Contact.get_one_by_id(contact_id)
    return jsonify(contact)

@app.route('/contacts/new', methods = ["POST"])
def create_page():
    print(f"From create: {request.data}")
    contact = request.get_json()
    id = Contact.save(contact)
    return jsonify({'id': id})

@app.route('/contacts/update/<int:contact_id>', methods=["PUT"])
def edit_page(contact_id):
    print(f"NOT ID: {contact_id}")
    data = request.get_json()
    print(f"Name Issue: {data}")
    # results = json.load(data)
    Contact.update({
        'id' : contact_id,
        **data
    })
    contact = Contact.get_one_by_id(contact_id)
    return jsonify(contact), 200

@app.route('/contacts/delete/<contact_id>' , methods=["DELETE"])
def delete_contact(contact_id):
    result = Contact.delete_by_id(contact_id)
    response = {
        'id': contact_id,
        'results' : result,
        
    }
    return (response)