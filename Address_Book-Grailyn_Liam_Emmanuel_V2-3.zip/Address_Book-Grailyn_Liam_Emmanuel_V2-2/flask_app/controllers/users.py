from flask import render_template,redirect,session,request,flash,session, jsonify
from flask_app import app
from flask_app.models.user import User
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)
from flask_app.models.contact import Contact

@app.route('/')
def login_reg():
    return render_template('login_reg.html')

@app.route('/register',methods=['POST'])
def register():
    # Currently not needed to meet the requirements of the assignment
    # Inorder to get this working we would have to create the user in the database
    # Then we would ascess that information and base all interactions on somekind of token system
    # if not User.validate_register(request.form):
    #     return redirect('/')
    data ={
        "first_name": request.form['first_name'],
        "last_name": request.form['last_name'],
        "email": request.form['email'],
        "password": bcrypt.generate_password_hash(request.form['password'])
    }
    id = User.save(data)
    # This session data would be difficult to manage since session isn't link to the client like a template.
    # session['user_id'] = id
    # Redirects would not be needed here the frontend would be the ione that handles this interaction
    # We would send data that verified theyr longed in status. not keep handle the templates.
    # return redirect('/contact')
    # For the time we would be sending back the user a id as a reference to their data on the database
    return jsonify({'user_id' : id})

@app.route('/login',methods=['POST'])
def login():
    user = User.get_by_email(request.form)
    if not user:
        # flash("Invalid Credentials, please try again", 'login')
        # return redirect('/')
        return {{'login' : 'Invalid Credentials, please try again'}}
    if not bcrypt.check_password_hash(user.password, request.form['password']):
        # flash messages are for tempaltes and are not transfered over through json unless we specify
        # flash("Invalid Credentials, please try again", 'login')
        # return redirect('/')
        return ({'login' : 'Invalid Credentials, please try again'})
    session['user_id'] = user.id
    return redirect('/dashboard')

@app.route('/logout')
def logout():
    # This session data would be changed everytime a new user logged in so we would have to use a different
    # system or jwt to track the users login state. We would invalidate the users key
    # session.clear()
    # No redirect would be necessary as this would be handled by the fronend.
    # return redirect('/')
    jsonify ({'authentication': 'invalidated'})