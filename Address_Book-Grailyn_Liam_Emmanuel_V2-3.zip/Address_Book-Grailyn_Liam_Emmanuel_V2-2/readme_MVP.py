                            #***    (MVP) MOST VIABLE PRODUCT (MVP) Instructions ***#


# Language Used	                                            PYTHON	        JAVA	        JAVASCRIPT
#! Project is on GitHub
#.gitignore file in root folder (Create one here)	        ✓	Although did not seem to save on gitignore website
#! All of CRUD* on a non-User table                         n/a      n/a             need to do
#! CSS implemented, and possibly other static content	    n/a      n/a             need to do
#! Data is validated upon create and edit, errors show	    n/a      n/a             need to do
#! Login and Registration with validations	                need to do      n/a	            Bonus
#! Protected routes (Must be logged in to view)	            need to do      n/a             Bonus
#! Application is responsive	                            Bonus	        Bonus           Bonus
#! Application uses a CSS framework such as Bootstrap	    Bonus	        Bonus           Bonus
#! Application is publicly deployed	                        Bonus	        Bonus           Bonus
#! Application features a third-party API	                Bonus	        Bonus           Bonus
#! File Upload	                                            Bonus	        Bonus           n/a
#! Many-to-many relationship (like, favorite, RSVP, etc)	Bonus	        Bonus           n/a
#! Socket.io			                                    n/a             n/a             Bonus
#! Pagination and Sorting		                            n/a             Bonus           n/a
#! Java Auth	                                            n/a             Bonus           n/a
#! AJAX	                                                    Bonus           n/a             n/a
#! Project uses Django instead of Flask                     Bonus           n/a             n/a


#!CRUD is working......  Create, Read, Update, Delete       need to do
    #! Complete the Re-Envisioning Your Schedule assignment, setting time aside to focus on your projects, and other time for algorithms.
    #! In a text file, a description of the project, its stack, a feature list, and GitHub repo link (can be empty at this point). You can include a product backlog that you plan to work on once your MVP is done.
    #! Create a wireframe image of the project you intend to build.
    #! Zip/compress both the text file detailing the project and wireframe image in a folder, and submit it for this assignment. Your instructor may want an email with this folder also to approve your project.